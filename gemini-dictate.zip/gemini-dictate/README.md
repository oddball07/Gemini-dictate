# Gemini Dictate

A Windows dictation tool that uses the **Gemini website's own speech-to-text**. A hidden Chrome/Edge/Brave window
(signed in to your Google account) does the listening; the text is pasted where you were typing and always left on
the clipboard. Optional AI cleanup and a **Prompt mode** turn rambling speech into a clean prompt.

| Hotkey | Action |
|---|---|
| `Ctrl+Alt+Space` | Start / stop dictation (Transcribe) |
| `Ctrl+Alt+P` | Start / stop dictation (Prompt mode) |
| `Ctrl+Alt+W` | Show / hide the widget (it starts hidden in the tray) |

## Install (no git clone needed)

You need Windows, Python 3.9+ (tick "Add to PATH") and Chrome, Edge or Brave.

```
pipx install gemini-dictate        # recommended (isolated)   -or-   pip install gemini-dictate
dictate                            # start it
dictate-setup startup on           # optional: start with Windows
```

From GitHub without cloning: `pip install git+https://github.com/<you>/gemini-dictate.git`

With npm: `npm install -g gemini-dictate` (it installs the Python part for you), then `dictate`, `dictate startup on`.

The first run opens the Gemini window once so you can sign in; after that it stays hidden.

## API keys (optional)
Set an environment variable or put the key in a file in your home folder:
`GROQ_API_KEY` / `~/.groq_key`, `GEMINI_API_KEY` / `~/.gemini_key`, `CEREBRAS_API_KEY` / `~/.cerebras_key`,
`OPENROUTER_API_KEY` / `~/.openrouter_key`.

## When no AI model works
1. API models are tried in order (models that failed earlier are retried if all were cooling down).
2. Fallback: the text is sent to the Gemini website chat (no API key needed).
3. Last resort: offline formatting.

## Helper commands
`dictate-setup startup on|off|status`, `dictate-setup rescue` (bring back windows an old version hid),
`dictate-setup migrate` (remove leftovers of the old `.pyw` / `.bat` install).

## Standalone
`gemini_widget.pyw` (same code) runs on its own: `pip install -r requirements.txt`, then double-click it.
